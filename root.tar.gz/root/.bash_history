history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
clear
cat /etc/debian_version
apt update
ip a
ping -c 8.8.8.8
ping -c 4 8.8.8.8
cat /etc/resolv.conf
echo "nameserver 8.8.8.8" > /etc/resolv.conf
cat /etc/resolv.conf
ping -c 4 deb.debian.org
clear
vi /etc/apt/sources.list
clear
vin /etc/apt/sources.list
vi /etc/apt/sources.list
clear
apt update
cat /etc/resolv.conf
echo 'supersede domain-servers 8.8.8.8, 1.1.1.1;' >> /etc/dhcp/dhclient.conf
dhclient -r enp0s3
dhclient enp0s3
cat /etc/resolv.conf
echo "nameserver 8.8.8.8" > /etc/resolv.conf
chattr +i /etc/resolv.conf
cat /etc/resolv.conf
ping -c 4 deb.debian.org
clear
apt update
apt upgrade
apt autoremove
vi /etc/apt/sources.list
clear
apt update
vim /etc/source.list
clear
vi /etc/apt/sources.list
apt update
clear
vi /etc/apt/sources.list
clear
apt update
apt full-upgrade
grub-install /dev/sda
update-grub
clear
cat /etc/debian_version
reboot
clear
mkdir -p /root/.ssh
chmod 700 /root/.shh
chmod 700 /root/.ssh
ls -ld /root/.ssh
cat > /tmp/clave_profesor.pub
clear
ssh-keygen -lf /tmp/clave_profesor.pub
touch /root/.ssh/authorized_keys
cat /tmp/clave_profesor.pub >> /root/.ssh/authorized_keys
chown root:root /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
ssh-keygen -lf /root/.ssh/authorized_keys
clear
clear
ls -l /root/clave_privada.txt
chmod 600 /root/clave_privada.txt
ls -l /root/clave_privada.txt
ssh -i /root/clave_privada.txt root@192.168.1.38
ls -l
cd .ssh
ls 
cat authorized_keys
ls
tar -xzvf Material_Adicional_TPVMCA.tar.gz
ls -l
cd Material_Adicional_TPVMCA/
ls -l
clear
apt-get install apache2 mariadb-server php libapache2-mod-php php-mysql
systemctl status apache2
ls -l
sytemctl status Apache2
systemctl status apache2
clear
lsblk
fdisk /dev/sdc
lsblk
clear
mkfs -t ext4 /dev/sdc1
mkfs -t ext4 /dev/sdc2
lsblk -f
clear
mkdir /www_dir
mkdir /backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
lsblk
blkid /dev/sdc1 /dev/sdc2
clear
ls -la /var/www/tp-web
cp /var/www/tp-web/index.php /www_dir/
cp /var/www/tp-web/logo.png /www_dir/
ls -l /www_dir
clear
vi /etc/apache2/sites-available/000-default.conf
clear
apache2ctl configtest
systemctl reload apache2
vi /etc/apache2/apache2.conf
clear
apche2ctl configtest
apache2ctl configtest
vi /etc/apache2/apache2.conf
clear
apache2ctl configtest
blqid
clear
blqid
blkid
cp /etc/fstab/ /etc/fstab.bak
cp /etc/fstab /etc/fstab.bak
vi /etc/fstab
clear
mount -a
/etc/fstab
vi /etc/fstab
clear
mount -a
clear
vi /etc/fstab
clear
mount -a
df -h
reboot
